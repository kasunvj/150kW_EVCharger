#!/bin/bash
sudo ifdown wlan0
sleep 1
sudo ifup wlan0
